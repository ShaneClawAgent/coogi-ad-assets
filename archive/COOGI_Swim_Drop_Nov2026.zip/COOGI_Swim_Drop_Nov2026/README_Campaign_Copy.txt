COOGI SWIM DROP - CAMPAIGN PACKAGE (Nov 20, 2026)
Shop link for everything: https://coogi.com/collections/swim
Hosted copies: github.com/ShaneClawAgent/coogi-ad-assets (email/swim-drop, tapcart/swim-drop)

PRODUCTS (Shopify)
- New - COOGI Swim T-Shirt - Boomerang ........ $100
- New - COOGI Swim T-Shirt - Classic Shirt .... $100
- New - COOGI Swim T-Shirt - Koala ............ $100
- New - COOGI Swim Trunks - Boomerang ......... $200
- New - COOGI Swim Trunks - Koala ............. $200
- New - COOGI Classic Swim Trunks ............. $250

=====================================================
OMNISEND EMAILS (drafts in Omnisend; Email 1 launched 11/20)
=====================================================
EMAIL 1 - "COOGI Swim Drop - 1 Packing List"
Subject: Your vacation packing list is missing something 🌴
Preheader: Passport ✔ Sunscreen ✔ COOGI Swim? Let's fix that.
Graphics: banner1_packed_for_paradise (top), option6_out_of_office, koala2_koala_season
Body: checklist (Passport / Sunscreen / Shades / Something worth getting photographed in),
"COOGI Swim is here", SHOP COOGI SWIM button, The Vacation Kit + P.S., 6-product grid.

EMAIL 2 - "COOGI Swim Drop - 2 Postcard Story"
Subject: Wish you were here. 🌊
Preheader: Postcards from somewhere warm - COOGI Swim has arrived.
Graphics: banner2_postcard (top), option4_boarding_pass, koala3_australian_since_1969
Body: "Dear traveler" story, Since 1969..., SHOP COOGI SWIM button,
Your Itinerary (Deck / Pool Bar / Beach / Sunset), P.S. tag @coogi, 6-product grid.

EMAIL 3 - "COOGI Swim Drop - 3 Drop Alert"
Subject: JUST DROPPED: COOGI SWIM 🔥
Preheader: Tees from $100. Trunks from $200. Built for the warm-weather escape.
Graphics: banner3_drop_alert (top), option5_pick_your_set, koala1_the_koala_set
Body: "COOGI Swim is live", 4 arrow bullets, SHOP COOGI SWIM button,
Get Yours Before You Board, 6-product grid.

=====================================================
TAPCART PUSH CAMPAIGN (use the HD 900x600 files)
=====================================================
1  Fri 11/20 7PM  | 🌴 COOGI Swim just dropped | Iconic COOGI prints, made for the water. Tap to shop the drop. | push1_just_dropped | SWIM All
2  Sat 11/21 12PM | 🐨 Koala season is here | The Koala tee + swim trunks. Matching is mandatory. | push2_koala_season | Swim Trunks - Koala
3  Sun 11/22 6PM  | The Classic... now swims 🌊 | The heritage COOGI print, built for the water. Classic Swim Trunks are here. | push3_the_classic | Classic Swim Trunks
4  Tue 11/24 12PM | 🧡 Join the Swim Team | The Boomerang tee + trunks. Front crest, big back. | push4_swim_team | Swim T-Shirt - Boomerang
5  Thu 11/26 7PM  | ✈️ Packed for paradise? | Passport ✔ Sunscreen ✔ COOGI Swim? Finish the list. | push5_packed_for_paradise | SWIM All
6  Sat 11/28 11AM | 👀 Pick your set | Boomerang, Classic or Koala. Tees $100, trunks from $200. | push6_pick_your_set | SWIM All
7  Tue 12/1 7PM   | 🛳️ Now boarding: COOGI Swim | Trip coming up? Order now so your fit lands before you do. | push7_now_boarding | SWIM All

Tapcart spec: JPEG/GIF/PNG, under 1 MB, 3:2 (help docs list 300x200; HD files are 3x for sharp phone screens).

=====================================================
WEBSITE HERO BANNERS (coogi.com homepage hero slideshow)
=====================================================
Desktop image: 2688x1512 (16:9) -> slide "Image"
Mobile image: 1080x1920 (9:16) -> slide "Mobile image"
Slide A: COOGI Swim (3 sets)   | Slide B: Koala Season
Link button to: SWIM All collection (/collections/swim)
Text and models kept below the transparent header area; bottom-center left open for the theme's button.
